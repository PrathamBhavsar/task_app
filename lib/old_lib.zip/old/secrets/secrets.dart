class AppSecrets {
  static String supabaseUrl = "https://dpgwbagzdsabjejngivi.supabase.co";
  static String supabaseAnonKey =
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRwZ3diYWd6ZHNhYmplam5naXZpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzU2MzEwNzYsImV4cCI6MjA1MTIwNzA3Nn0.-k9v63LGVOgh5uii5iEcNPruNwBj-AxSeFVklGnXSds";
  static String supabaseSecureKey =
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRwZ3diYWd6ZHNhYmplam5naXZpIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTczNTYzMTA3NiwiZXhwIjoyMDUxMjA3MDc2fQ.P_GcxAWZXPoVf0mhkQgBRSS5klej1Rs7m4nDBdqs7hA";

  static String apiKey = "a;lskdfjireckhdsfdfsdfgelskhfcca";
}
